const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const app = express();
const port = 3000;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// Database setup
const db = new sqlite3.Database('./students.db', (err) => {
    if (err) {
        console.error('Error connecting to database:', err.message);
    } else {
        console.log('Connected to the SQLite database.');
        // Create table if it doesn't exist
        db.run(`CREATE TABLE IF NOT EXISTS students (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE,
            dob TEXT NOT NULL,
            department TEXT NOT NULL,
            phone TEXT NOT NULL
        )`);
    }
});

// API Routes

// Store data
app.post('/api/register', (req, res) => {
    const { name, email, dob, department, phone } = req.body;
    
    const sql = `INSERT INTO students (name, email, dob, department, phone) VALUES (?, ?, ?, ?, ?)`;
    db.run(sql, [name, email, dob, department, phone], function(err) {
        if (err) {
            console.error(err.message);
            return res.status(500).json({ success: false, message: 'Database error. Email might already exist.' });
        }
        res.json({ success: true, message: 'Student registered successfully!', id: this.lastID });
    });
});

// Retrieve data using SELECT
app.get('/api/students', (req, res) => {
    const sql = `SELECT * FROM students ORDER BY id DESC`;
    db.all(sql, [], (err, rows) => {
        if (err) {
            console.error(err.message);
            return res.status(500).json({ success: false, message: 'Database error.' });
        }
        res.json({ success: true, data: rows });
    });
});

app.listen(port, () => {
    console.log(`Server is running at http://localhost:${port}`);
});
