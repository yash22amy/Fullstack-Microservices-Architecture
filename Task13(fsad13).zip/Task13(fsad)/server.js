const express = require('express');
const app = express();

app.use(express.json());

// In-memory data
let products = [
    { id: 1, name: "Laptop", price: 50000, quantity: 5 },
    { id: 2, name: "Mobile", price: 20000, quantity: 10 }
];

//  Root route
app.get('/', (req, res) => {
    res.send("Product API with Validation & Exception Handling 🚀");
});

//  Validation function
function validateProduct(req, res, next) {
    const { name, price, quantity } = req.body;

    if (!name || typeof name !== 'string') {
        return res.status(400).json({ error: "Name is required and must be a string" });
    }

    if (price == null || typeof price !== 'number' || price <= 0) {
        return res.status(400).json({ error: "Price must be a positive number" });
    }

    if (quantity == null || typeof quantity !== 'number' || quantity < 0) {
        return res.status(400).json({ error: "Quantity must be a non-negative number" });
    }

    next();
}

//  GET all
app.get('/api/products', (req, res) => {
    res.json(products);
});

//  GET by ID
app.get('/api/products/:id', (req, res, next) => {
    try {
        const product = products.find(p => p.id == req.params.id);

        if (!product) {
            return res.status(404).json({ error: "Product not found" });
        }

        res.json(product);
    } catch (err) {
        next(err);
    }
});

//  POST (Create)
app.post('/api/products', validateProduct, (req, res, next) => {
    try {
        const { name, price, quantity } = req.body;

        const newProduct = {
            id: products.length ? products[products.length - 1].id + 1 : 1,
            name,
            price,
            quantity
        };

        products.push(newProduct);
        res.status(201).json(newProduct);

    } catch (err) {
        next(err);
    }
});

// PUT (Update)
app.put('/api/products/:id', (req, res, next) => {
    try {
        const product = products.find(p => p.id == req.params.id);

        if (!product) {
            return res.status(404).json({ error: "Product not found" });
        }

        const { name, price, quantity } = req.body;

        // Partial validation
        if (name !== undefined && typeof name !== 'string') {
            return res.status(400).json({ error: "Name must be a string" });
        }

        if (price !== undefined && (typeof price !== 'number' || price <= 0)) {
            return res.status(400).json({ error: "Price must be positive number" });
        }

        if (quantity !== undefined && (typeof quantity !== 'number' || quantity < 0)) {
            return res.status(400).json({ error: "Quantity must be non-negative" });
        }

        if (name !== undefined) product.name = name;
        if (price !== undefined) product.price = price;
        if (quantity !== undefined) product.quantity = quantity;

        res.json(product);

    } catch (err) {
        next(err);
    }
});

//  DELETE
app.delete('/api/products/:id', (req, res, next) => {
    try {
        const index = products.findIndex(p => p.id == req.params.id);

        if (index === -1) {
            return res.status(404).json({ error: "Product not found" });
        }

        const deleted = products.splice(index, 1);

        res.json({
            message: "Product deleted successfully",
            product: deleted[0]
        });

    } catch (err) {
        next(err);
    }
});

// Global Exception Handler (IMPORTANT)
app.use((err, req, res, next) => {
    console.error(err.stack);

    res.status(500).json({
        error: "Internal Server Error",
        message: err.message
    });
});

//  Start server
const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});
