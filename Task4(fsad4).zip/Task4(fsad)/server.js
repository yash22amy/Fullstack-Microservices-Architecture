const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const cors = require('cors');
const path = require('path');

const app = express();
const port = 3001;

app.use(cors());
app.use(express.static('public'));
app.use(express.json());

// Database Initialization
const db = new sqlite3.Database(':memory:', (err) => {
    if (err) {
        console.error(err.message);
    }
    console.log('Connected to the in-memory SQlite database.');
});

db.serialize(() => {
    // Create Tables
    db.run(`CREATE TABLE Customers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL
    )`);

    db.run(`CREATE TABLE Products (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        price REAL NOT NULL
    )`);

    db.run(`CREATE TABLE Orders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        customer_id INTEGER,
        product_id INTEGER,
        quantity INTEGER NOT NULL,
        order_date DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (customer_id) REFERENCES Customers(id),
        FOREIGN KEY (product_id) REFERENCES Products(id)
    )`);

    // Seed Data
    const customers = [
        ['Alice Johnson', 'alice@example.com'],
        ['Bob Smith', 'bob@example.com'],
        ['Charlie Brown', 'charlie@example.com'],
        ['Diana Prince', 'diana@example.com']
    ];
    const products = [
        ['Laptop', 1200.00],
        ['Smartphone', 800.00],
        ['Headphones', 150.00],
        ['Monitor', 300.00],
        ['Keyboard', 50.00]
    ];
    const orders = [
        [1, 1, 1], // Alice -> Laptop
        [1, 3, 2], // Alice -> 2 Headphones
        [2, 2, 1], // Bob -> Smartphone
        [3, 4, 1], // Charlie -> Monitor
        [3, 5, 2], // Charlie -> 2 Keyboards
        [1, 2, 1], // Alice -> Smartphone
        [4, 1, 1], // Diana -> Laptop
        [2, 3, 3]  // Bob -> 3 Headphones
    ];

    let stmt = db.prepare("INSERT INTO Customers (name, email) VALUES (?, ?)");
    customers.forEach(c => stmt.run(c));
    stmt.finalize();

    stmt = db.prepare("INSERT INTO Products (name, price) VALUES (?, ?)");
    products.forEach(p => stmt.run(p));
    stmt.finalize();

    stmt = db.prepare("INSERT INTO Orders (customer_id, product_id, quantity) VALUES (?, ?, ?)");
    orders.forEach(o => stmt.run(o));
    stmt.finalize();
});

// API Endpoints

// 1. Order History using JOIN
app.get('/api/orders', (req, res) => {
    const query = `
        SELECT 
            o.id, 
            c.name AS customer_name, 
            p.name AS product_name, 
            o.quantity, 
            (p.price * o.quantity) AS total_price, 
            o.order_date 
        FROM Orders o
        JOIN Customers c ON o.customer_id = c.id
        JOIN Products p ON o.product_id = p.id
        ORDER BY o.order_date DESC
    `;
    db.all(query, [], (err, rows) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(rows);
    });
});

// 2. Analytics using Subqueries
app.get('/api/stats', (req, res) => {
    // Highest value order using subquery
    const highestValueQuery = `
        SELECT o.id, c.name as customer_name, (p.price * o.quantity) as total_value
        FROM Orders o
        JOIN Customers c ON o.customer_id = c.id
        JOIN Products p ON o.product_id = p.id
        WHERE (p.price * o.quantity) = (
            SELECT MAX(p2.price * o2.quantity) 
            FROM Orders o2 
            JOIN Products p2 ON o2.product_id = p2.id
        )
    `;

    // Most active customer using subquery
    const mostActiveQuery = `
        SELECT name, order_count 
        FROM (
            SELECT c.name, COUNT(o.id) as order_count
            FROM Customers c
            JOIN Orders o ON c.id = o.customer_id
            GROUP BY c.id
        ) AS activity
        WHERE order_count = (
            SELECT MAX(cnt) 
            FROM (
                SELECT COUNT(id) as cnt 
                FROM Orders 
                GROUP BY customer_id
            ) AS counts
        )
    `;

    db.get(highestValueQuery, [], (err, highest) => {
        if (err) return res.status(500).json({ error: err.message });
        
        db.get(mostActiveQuery, [], (err, active) => {
            if (err) return res.status(500).json({ error: err.message });
            res.json({ highestOrder: highest, mostActive: active });
        });
    });
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
