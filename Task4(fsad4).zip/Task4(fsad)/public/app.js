document.addEventListener('DOMContentLoaded', () => {
    fetchOrders();
    fetchStats();
});

async function fetchOrders() {
    try {
        const response = await fetch('/api/orders');
        const orders = await response.json();
        const tableBody = document.getElementById('orders-body');
        
        tableBody.innerHTML = orders.map(order => `
            <tr>
                <td>#${order.id}</td>
                <td><div style="font-weight:600">${order.customer_name}</div></td>
                <td>${order.product_name}</td>
                <td>${order.quantity}</td>
                <td><span style="color:#10b981; font-weight:700">$${order.total_price.toFixed(2)}</span></td>
                <td>${new Date(order.order_date).toLocaleDateString()}</td>
            </tr>
        `).join('');
    } catch (error) {
        console.error('Error fetching orders:', error);
    }
}

async function fetchStats() {
    try {
        const response = await fetch('/api/stats');
        const stats = await response.json();
        
        const highestOrderEl = document.getElementById('highest-order').querySelector('.value');
        const mostActiveEl = document.getElementById('most-active').querySelector('.value');
        
        if (stats.highestOrder) {
            highestOrderEl.innerHTML = `\$${stats.highestOrder.total_value.toFixed(2)} <span style="font-size:0.8rem; color:#94a3b8; font-weight:400">by ${stats.highestOrder.customer_name}</span>`;
            highestOrderEl.classList.remove('loading');
        }
        
        if (stats.mostActive) {
            mostActiveEl.innerHTML = `${stats.mostActive.name} <span style="font-size:0.8rem; color:#94a3b8; font-weight:400">(${stats.mostActive.order_count} orders)</span>`;
            mostActiveEl.classList.remove('loading');
        }
    } catch (error) {
        console.error('Error fetching stats:', error);
    }
}
