document.getElementById("empForm").addEventListener("submit", async function(e) {
    e.preventDefault();

    const name = document.getElementById("name").value;
    const department = document.getElementById("department").value;
    const salary = document.getElementById("salary").value;

    if (!name || !department || !salary) {
        alert("All fields are required!");
        return;
    }

    const res = await fetch("/addEmployee", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            name: name,
            department: department,
            salary: salary
        })
    });

    const msg = await res.text();
    alert(msg);

    document.getElementById("empForm").reset();

    loadEmployees();
});

async function loadEmployees() {
    const res = await fetch("/employees");
    const data = await res.json();

    const table = document.getElementById("empTable");
    table.innerHTML = "";

    data.forEach(emp => {
        table.innerHTML += `
            <tr>
                <td>${emp.id}</td>
                <td>${emp.name}</td>
                <td>${emp.department}</td>
                <td>${emp.salary}</td>
            </tr>
        `;
    });
}
loadEmployees();
