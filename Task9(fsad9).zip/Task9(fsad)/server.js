const express = require('express');
const db = require('./db');

const app = express();

app.use(express.json());
app.use(express.static('public'));

app.get('/employees', (req, res) => {
    db.query("SELECT * FROM employees", (err, result) => {
        if (err) {
            console.log(err);
            return res.status(500).send("Error");
        }
        res.json(result);
    });
});

app.post('/addEmployee', (req, res) => {
    const { name, department, salary } = req.body;

    if (!name || !department || !salary) {
        return res.send("Missing data");
    }

    db.query(
        "INSERT INTO employees (name, department, salary) VALUES (?, ?, ?)",
        [name, department, salary],
        (err) => {
            if (err) {
                console.log(err);
                return res.send("DB Error");
            }
            res.send("Employee Added Successfully");
        }
    );
});

app.listen(3000, () => {
    console.log("Server running at http://localhost:3000");
});
