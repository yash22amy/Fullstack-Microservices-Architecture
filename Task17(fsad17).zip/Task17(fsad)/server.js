const express = require("express");
const axios = require("axios");

/* =========================================
   SERVICE B (Provider)
   ========================================= */
const serviceB = express();

// Root route (fix for Cannot GET /)
serviceB.get("/", (req, res) => {
    res.send("✅ Service B is running on port 4000");
});

// Normal API
serviceB.get("/data", (req, res) => {
    res.json({
        success: true,
        message: "Data from Service B",
        data: {
            id: 101,
            name: "Microservice Example"
        }
    });
});

// Error simulation
serviceB.get("/error", (req, res) => {
    res.status(500).json({
        success: false,
        message: "Service B Internal Error"
    });
});

serviceB.listen(4000, () => {
    console.log("🚀 Service B running at http://localhost:4000");
});

/* =========================================
   SERVICE A (Consumer)
   ========================================= */
const app = express();

// Root route (fix for Cannot GET /)
app.get("/", (req, res) => {
    res.send("✅ Service A is running on port 3000");
});

// Call Service B (SUCCESS)
app.get("/fetch-data", async (req, res) => {
    try {
        const response = await axios.get("http://localhost:4000/data", {
            timeout: 3000
        });

        res.json({
            success: true,
            service: "A",
            dataFromB: response.data
        });

    } catch (error) {
        res.status(500).json({
            success: false,
            message: "Error communicating with Service B",
            error: error.message,
            fallback: {
                data: "Default fallback data"
            }
        });
    }
});

// Call Service B (ERROR HANDLING)
app.get("/fetch-error", async (req, res) => {
    try {
        const response = await axios.get("http://localhost:4000/error");

        res.json(response.data);

    } catch (error) {
        res.status(500).json({
            success: false,
            message: "Handled Service B failure",
            error: error.response ? error.response.data : error.message,
            fallback: "Using backup response"
        });
    }
});

app.listen(3000, () => {
    console.log("🚀 Service A running at http://localhost:3000");
});


