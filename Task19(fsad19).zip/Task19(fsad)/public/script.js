const API = "http://localhost:3000/students";

async function addStudent() {
    const name = document.getElementById("name").value;
    const age = document.getElementById("age").value;

    await fetch(API, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, age })
    });

    loadStudents();
}

async function loadStudents() {
    const res = await fetch(API);
    const data = await res.json();

    const list = document.getElementById("list");
    list.innerHTML = "";

    data.forEach(s => {
        const li = document.createElement("li");
        li.innerText = `${s.name} - ${s.age}`;
        list.appendChild(li);
    });
}
loadStudents();
