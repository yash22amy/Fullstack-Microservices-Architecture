const express = require("express");
const cors = require("cors");
const db = require("./db");

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static("public"));

app.get("/students", (req, res) => {
    db.query("SELECT * FROM students", (err, result) => {
        if (err) throw err;
        res.json(result);
    });
});

app.post("/students", (req, res) => {
    const { name, age } = req.body;
    db.query(
        "INSERT INTO students (name, age) VALUES (?, ?)",
        [name, age],
        (err) => {
            if (err) throw err;
            res.send("Student Added");
        }
    );
});

app.listen(3000, () => {
    console.log("Server running on http://localhost:3000");
});
