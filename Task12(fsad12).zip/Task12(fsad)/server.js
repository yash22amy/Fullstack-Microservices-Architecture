const express = require('express');
const app = express();

app.use(express.json());

// In-memory data
let products = [
    { id: 1, name: "Laptop", price: 50000, quantity: 5 },
    { id: 2, name: "Mobile", price: 20000, quantity: 10 }
];

// ✅ Root route (FIX for "Cannot GET /")
app.get('/', (req, res) => {
    res.send("Product API is running 🚀");
});

// ✅ GET all products
app.get('/api/products', (req, res) => {
    res.json(products);
});

// ✅ GET product by ID
app.get('/api/products/:id', (req, res) => {
    const product = products.find(p => p.id == req.params.id);

    if (!product) {
        return res.status(404).json({ message: "Product not found" });
    }

    res.json(product);
});

// ✅ POST (Create product)
app.post('/api/products', (req, res) => {
    const { name, price, quantity } = req.body;

    // Basic validation
    if (!name || price == null || quantity == null) {
        return res.status(400).json({ message: "All fields are required" });
    }

    const newProduct = {
        id: products.length ? products[products.length - 1].id + 1 : 1,
        name,
        price,
        quantity
    };

    products.push(newProduct);
    res.status(201).json(newProduct);
});

// ✅ PUT (Update product)
app.put('/api/products/:id', (req, res) => {
    const product = products.find(p => p.id == req.params.id);

    if (!product) {
        return res.status(404).json({ message: "Product not found" });
    }

    const { name, price, quantity } = req.body;

    if (name !== undefined) product.name = name;
    if (price !== undefined) product.price = price;
    if (quantity !== undefined) product.quantity = quantity;

    res.json(product);
});

// ✅ DELETE product
app.delete('/api/products/:id', (req, res) => {
    const index = products.findIndex(p => p.id == req.params.id);

    if (index === -1) {
        return res.status(404).json({ message: "Product not found" });
    }

    const deletedProduct = products.splice(index, 1);

    res.json({
        message: "Product deleted successfully",
        product: deletedProduct[0]
    });
});

// Start server
const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});
