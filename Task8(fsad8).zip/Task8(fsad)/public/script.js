const API = "http://localhost:3000/employees";

async function loadEmployees() {
    const res = await fetch(API);
    const data = await res.json();

    const list = document.getElementById("list");
    list.innerHTML = "";

    data.forEach(emp => {
        const li = document.createElement("li");
        li.innerText = `${emp.name} - ${emp.role}`;
        list.appendChild(li);
    });
}

async function addEmployee() {
    const name = document.getElementById("name").value;
    const role = document.getElementById("role").value;

    if (!name || !role) {
        alert("Enter all fields");
        return;
    }

    await fetch(API, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, role })
    });

    loadEmployees();
}

loadEmployees();
