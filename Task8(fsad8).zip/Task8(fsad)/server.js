const express = require("express");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static("public"));

// Dependency Injection (@Autowired)
const repo = require("./db");

// Service Layer
class EmployeeService {
    constructor(repository) {
        this.repo = repository;
    }

    getEmployees(res) {
        this.repo.getAll((err, result) => {
            if (err) res.send(err);
            else res.json(result);
        });
    }

    addEmployee(data, res) {
        this.repo.add(data, err => {
            if (err) res.send(err);
            else res.send("Employee Added");
        });
    }
}

// BeanFactory simulation
const service = new EmployeeService(repo);

// Routes
app.get("/employees", (req, res) => {
    service.getEmployees(res);
});

app.post("/employees", (req, res) => {
    service.addEmployee(req.body, res);
});

app.listen(3000, () => {
    console.log("Server running at http://localhost:3000");
});
