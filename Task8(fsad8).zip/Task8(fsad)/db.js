const mysql = require("mysql2");

// Repository Bean
class EmployeeRepository {
    constructor() {
        this.db = mysql.createConnection({
            host: "localhost",
            user: "root",
            password: "Rishitha@173",
            database: "employee_db"
        });

        this.db.connect(err => {
            if (err) console.log("DB Error:", err);
            else console.log("MySQL Connected");
        });
    }

    getAll(callback) {
        this.db.query("SELECT * FROM employees", callback);
    }

    add(emp, callback) {
        this.db.query(
            "INSERT INTO employees (name, role) VALUES (?, ?)",
            [emp.name, emp.role],
            callback
        );
    }
}

// Export singleton (BeanFactory)
module.exports = new EmployeeRepository();

