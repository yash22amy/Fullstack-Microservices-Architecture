const mysql = require('mysql2');

const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'Rishitha@173',
    database: 'student'
});

db.connect(err => {
    if (err) console.log(err);
    else console.log("MySQL Connected...");
});

// 📌 Get students with filtering + sorting + pagination
exports.getStudents = (filters, callback) => {
    let query = "SELECT * FROM students WHERE 1=1";
    let values = [];

    // Filter by department
    if (filters.department) {
        query += " AND department = ?";
        values.push(filters.department);
    }

    // Filter by age
    if (filters.age) {
        query += " AND age >= ?";
        values.push(filters.age);
    }

    // Sorting
    if (filters.sortBy) {
        query += ` ORDER BY ${filters.sortBy}`;
    }

    // Pagination
    const limit = parseInt(filters.limit) || 5;
    const offset = ((parseInt(filters.page) || 1) - 1) * limit;

    query += " LIMIT ? OFFSET ?";
    values.push(limit, offset);

    db.query(query, values, callback);
};
