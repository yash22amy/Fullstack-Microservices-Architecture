let page = 1;

function loadStudents() {
    const dept = document.getElementById("department").value;
    const age = document.getElementById("age").value;
    const sort = document.getElementById("sort").value;

    fetch(`http://localhost:3000/students?department=${dept}&age=${age}&sortBy=${sort}&page=${page}&limit=5`)
        .then(res => res.json())
        .then(data => {
            const table = document.getElementById("data");
            table.innerHTML = "";

            data.forEach(s => {
                table.innerHTML += `
                    <tr>
                        <td>${s.id}</td>
                        <td>${s.name}</td>
                        <td>${s.age}</td>
                        <td>${s.department}</td>
                    </tr>
                `;
            });

            document.getElementById("pageNum").innerText = page;
        });
}

function nextPage() {
    page++;
    loadStudents();
}

function prevPage() {
    if (page > 1) {
        page--;
        loadStudents();
    }
}

// Initial load
loadStudents();
