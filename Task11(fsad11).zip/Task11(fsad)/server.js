const express = require('express');
const cors = require('cors');
const db = require('./db');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// API - Get students with filters
app.get('/students', (req, res) => {
    db.getStudents(req.query, (err, results) => {
        if (err) return res.json(err);
        res.json(results);
    });
});

app.listen(3000, () => {
    console.log("Server running at http://localhost:3000");
});
