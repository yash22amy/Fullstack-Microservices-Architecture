const express = require("express");
const cors = require("cors");
const db = require("./db");

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static("public"));

// GET
app.get("/students", (req, res) => {
    db.query("SELECT * FROM students", (err, result) => {
        if (err) throw err;
        res.json(result);
    });
});

// POST
app.post("/students", (req, res) => {
    const { name } = req.body;
    db.query("INSERT INTO students (name) VALUES (?)", [name], (err) => {
        if (err) throw err;
        res.send("Added");
    });
});

app.listen(3000, () => console.log("Server running on 3000"));
