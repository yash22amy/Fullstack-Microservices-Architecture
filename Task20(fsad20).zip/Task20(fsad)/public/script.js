const API = "http://localhost:3000/students";

function fetchStudents() {
    fetch(API)
    .then(res => res.json())
    .then(data => {
        const list = document.getElementById("list");
        list.innerHTML = "";

        data.forEach(s => {
            list.innerHTML += `<li>${s.name}</li>`;
        });
    });
}

function addStudent() {
    const name = document.getElementById("name").value;

    fetch(API, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name })
    }).then(() => {
        fetchStudents();
    });
}

fetchStudents();
