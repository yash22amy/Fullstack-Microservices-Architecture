const express = require('express');
const bodyParser = require('body-parser');
const db = require('./db');
const app = express();

app.use(bodyParser.json());
app.use(express.static('public'));

// CREATE
app.post('/addStudent', (req, res) => {
    const { name, email, course } = req.body;

    const sql = "INSERT INTO students (name, email, course) VALUES (?, ?, ?)";
    db.query(sql, [name, email, course], (err, result) => {
        if (err) return res.send(err);
        res.send("Student Added");
    });
});

// READ
app.get('/students', (req, res) => {
    db.query("SELECT * FROM students", (err, result) => {
        if (err) return res.send(err);
        res.json(result);
    });
});

// UPDATE
app.put('/updateStudent/:id', (req, res) => {
    const { name, email, course } = req.body;
    const id = req.params.id;

    const sql = "UPDATE students SET name=?, email=?, course=? WHERE id=?";
    db.query(sql, [name, email, course, id], (err) => {
        if (err) return res.send(err);
        res.send("Student Updated");
    });
});

// DELETE
app.delete('/deleteStudent/:id', (req, res) => {
    const id = req.params.id;

    db.query("DELETE FROM students WHERE id=?", [id], (err) => {
        if (err) return res.send(err);
        res.send("Student Deleted");
    });
});

app.listen(3000, () => {
    console.log("Server running at http://localhost:3000");
});
