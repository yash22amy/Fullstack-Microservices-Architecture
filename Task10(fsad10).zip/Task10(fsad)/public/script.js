const form = document.getElementById('studentForm');

form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const data = {
        name: document.getElementById('name').value,
        email: document.getElementById('email').value,
        course: document.getElementById('course').value
    };

    await fetch('/addStudent', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    });

    form.reset();
    loadStudents();
});

async function loadStudents() {
    const res = await fetch('/students');
    const students = await res.json();

    const table = document.getElementById('studentTable');
    table.innerHTML = "";

    students.forEach(s => {
        table.innerHTML += `
            <tr>
                <td>${s.id}</td>
                <td>${s.name}</td>
                <td>${s.email}</td>
                <td>${s.course}</td>
                <td>
                    <button onclick="deleteStudent(${s.id})">Delete</button>
                </td>
            </tr>
        `;
    });
}

async function deleteStudent(id) {
    await fetch('/deleteStudent/' + id, {
        method: 'DELETE'
    });

    loadStudents();
}

loadStudents();
