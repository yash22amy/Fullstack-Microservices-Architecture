const mysql = require('mysql2');

const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'Rishitha@173', 
    database: 'student_crud'
});

db.connect(err => {
    if (err) {
        console.log("DB Connection Failed:", err);
    } else {
        console.log("Connected to MySQL");
    }
});

module.exports = db;


