document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('loginForm');
    const usernameInput = document.getElementById('username');
    const passwordInput = document.getElementById('password');
    const usernameError = document.getElementById('usernameError');
    const passwordError = document.getElementById('passwordError');
    const errorMessage = document.getElementById('errorMessage');
    const successMessage = document.getElementById('successMessage');
    const submitBtn = document.getElementById('submitBtn');
    const btnText = document.querySelector('.btn-text');
    const loader = document.getElementById('loader');

    // Real-time validation
    usernameInput.addEventListener('input', () => validateUsername());
    passwordInput.addEventListener('input', () => validatePassword());

    function validateUsername() {
        const username = usernameInput.value.trim();
        if (username === '') {
            usernameError.textContent = 'Username is required';
            usernameInput.style.borderColor = '#ef4444';
            return false;
        } else if (username.length < 3) {
            usernameError.textContent = 'Username must be at least 3 characters';
            usernameInput.style.borderColor = '#ef4444';
            return false;
        }
        
        usernameError.textContent = '';
        usernameInput.style.borderColor = 'rgba(255, 255, 255, 0.1)';
        return true;
    }

    function validatePassword() {
        const password = passwordInput.value.trim();
        if (password === '') {
            passwordError.textContent = 'Password is required';
            passwordInput.style.borderColor = '#ef4444';
            return false;
        } else if (password.length < 6) {
            passwordError.textContent = 'Password must be at least 6 characters';
            passwordInput.style.borderColor = '#ef4444';
            return false;
        }
        
        passwordError.textContent = '';
        passwordInput.style.borderColor = 'rgba(255, 255, 255, 0.1)';
        return true;
    }

    // Form Submission
    loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();

        // Reset server messages
        errorMessage.style.display = 'none';
        successMessage.style.display = 'none';

        // Perform validation
        const isUsernameValid = validateUsername();
        const isPasswordValid = validatePassword();

        if (!isUsernameValid || !isPasswordValid) {
            // Apply shake animation to form to indicate validation failure
            loginForm.classList.remove('shake');
            void loginForm.offsetWidth; // Trigger reflow
            loginForm.classList.add('shake');
            return;
        }

        const username = usernameInput.value.trim();
        const password = passwordInput.value.trim();

        // UI Loading State
        submitBtn.disabled = true;
        btnText.style.display = 'none';
        loader.style.display = 'block';

        try {
            // Check credentials from database (simulated delay for smooth UX)
            await new Promise(resolve => setTimeout(resolve, 800));

            const response = await fetch('http://localhost:3003/api/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ username, password })
            });

            const data = await response.json();

            if (response.ok && data.success) {
                // Success Scenario
                loginForm.style.display = 'none';
                successMessage.textContent = data.message;
                successMessage.style.display = 'block';
            } else {
                // Server Side Error (Dynamic Error Message)
                errorMessage.textContent = data.message || 'Login failed. Please try again.';
                errorMessage.style.display = 'block';
            }
        } catch (error) {
            console.error('Network Error:', error);
            errorMessage.textContent = 'Could not connect to the server. Please check your network.';
            errorMessage.style.display = 'block';
        } finally {
            // Restore UI State
            submitBtn.disabled = false;
            btnText.style.display = 'block';
            loader.style.display = 'none';
        }
    });
});
