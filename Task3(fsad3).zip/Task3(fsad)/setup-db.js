const sqlite3 = require('sqlite3').verbose();
const path = require('path');

// Create or connect to the SQLite database
const dbPath = path.resolve(__dirname, 'database.sqlite');
const db = new sqlite3.Database(dbPath, (err) => {
    if (err) {
        console.error('Error opening database', err.message);
    } else {
        console.log('Connected to the SQLite database.');
        
        // Create users table
        db.run(`CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE,
            password TEXT
        )`, (err) => {
            if (err) {
                console.error('Error creating table', err.message);
            } else {
                console.log('Users table ready.');
                
                // Insert a test user
                const insert = 'INSERT OR IGNORE INTO users (username, password) VALUES (?, ?)';
                // Note: In a real application, passwords should ALWAYS be hashed (e.g. using bcrypt).
                // We are using plain text here just for the purpose of demonstrating the credential check.
                db.run(insert, ['admin', 'password123'], function(err) {
                    if (err) {
                        return console.log(err.message);
                    }
                    console.log('Test user "admin" with password "password123" added or already exists.');
                    console.log('Setup complete.');
                    db.close();
                });
            }
        });
    }
});
