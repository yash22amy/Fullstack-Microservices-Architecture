function addUser() {
    const name = document.getElementById("name").value;
    const email = document.getElementById("email").value;

    fetch('/addUser', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email })
    })
    .then(res => res.text())
    .then(data => alert(data));
}

function updateUser() {
    const id = document.getElementById("uid").value;
    const name = document.getElementById("name").value;
    const email = document.getElementById("email").value;

    fetch('/updateUser/' + id, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email })
    })
    .then(res => res.text())
    .then(data => alert(data));
}

function getLogs() {
    fetch('/logs')
    .then(res => res.json())
    .then(data => {
        const list = document.getElementById("logs");
        list.innerHTML = "";
        data.forEach(log => {
            list.innerHTML += `<li>User ${log.user_id} - ${log.action} at ${log.action_time}</li>`;
        });
    });
}
function getReport() {
    fetch('/report')
    .then(res => res.json())
    .then(data => {
        const list = document.getElementById("report");
        list.innerHTML = "";
        data.forEach(r => {
            list.innerHTML += `<li>${r.date} - ${r.action}: ${r.total_actions}</li>`;
        });
    });
}
