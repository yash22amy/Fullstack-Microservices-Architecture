const express = require('express');
const bodyParser = require('body-parser');
const db = require('./db');
const app = express();

app.use(bodyParser.json());
app.use(express.static('public'));

app.post('/addUser', (req, res) => {
    const { name, email } = req.body;

    const sql = "INSERT INTO users(name, email) VALUES (?, ?)";
    db.query(sql, [name, email], (err) => {
        if (err) return res.send(err);
        res.send("User Added");
    });
});

app.put('/updateUser/:id', (req, res) => {
    const { name, email } = req.body;

    const sql = "UPDATE users SET name=?, email=? WHERE id=?";
    db.query(sql, [name, email, req.params.id], (err) => {
        if (err) return res.send(err);
        res.send("User Updated");
    });
});

app.get('/logs', (req, res) => {
    db.query("SELECT * FROM user_logs", (err, result) => {
        if (err) return res.send(err);
        res.json(result);
    });
});

app.get('/report', (req, res) => {
    db.query("SELECT * FROM daily_activity", (err, result) => {
        if (err) return res.send(err);
        res.json(result);
    });
});

app.listen(3000, () => {
    console.log("Server running at http://localhost:3000");
});