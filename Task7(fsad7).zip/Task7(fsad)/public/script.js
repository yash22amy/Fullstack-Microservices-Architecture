// Validation functions
function validateName(name) {
    return name.length >= 3;
}

function validateEmail(email) {
    let regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(email);
}

function validateMessage(msg) {
    return msg.length >= 5;
}

// Real-time validation
document.getElementById("name").addEventListener("keyup", function () {
    this.style.borderColor = validateName(this.value.trim()) ? "green" : "red";
});

document.getElementById("email").addEventListener("keyup", function () {
    this.style.borderColor = validateEmail(this.value.trim()) ? "green" : "red";
});

document.getElementById("message").addEventListener("keyup", function () {
    this.style.borderColor = validateMessage(this.value.trim()) ? "green" : "red";
});

// Form submit
document.getElementById("feedbackForm").addEventListener("submit", function(e) {
    e.preventDefault(); // prevent page reload

    let name = document.getElementById("name").value.trim();
    let email = document.getElementById("email").value.trim();
    let message = document.getElementById("message").value.trim();

    let status = document.getElementById("status");

    if (!validateName(name)) {
        status.innerText = "Name must be at least 3 characters";
        return;
    }

    if (!validateEmail(email)) {
        status.innerText = "Enter a valid email";
        return;
    }

    if (!validateMessage(message)) {
        status.innerText = "Message must be at least 5 characters";
        return;
    }

    // Send data to server
    fetch("/submit", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({ name, email, message })
    })
    .then(res => res.text())
    .then(data => {
        status.innerText = data;

        // reset form after success
        document.getElementById("feedbackForm").reset();
    })
    .catch(() => {
        status.innerText = "Server error!";
    });
});
