const mysql = require("mysql2");

const connection = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "Rishitha@173",   // your MySQL password
    database: "feedback_db"
});

connection.connect((err) => {
    if (err) {
        console.log("DB Connection Failed:", err);
    } else {
        console.log("Connected to MySQL");
    }
});

module.exports = connection;