const express = require("express");
const db = require("./db");

const app = express();

app.use(express.json());
app.use(express.static("public"));

// Route to submit feedback
app.post("/submit", (req, res) => {
    const { name, email, message } = req.body;

    const sql = "INSERT INTO feedback (name, email, message) VALUES (?, ?, ?)";
    db.query(sql, [name, email, message], (err) => {
        if (err) {
            console.log(err);
            res.send("Error saving feedback");
        } else {
            res.send("Feedback Submitted Successfully!");
        }
    });
});

// Start server
app.listen(3000, () => {
    console.log("Server running at http://localhost:3000");
});