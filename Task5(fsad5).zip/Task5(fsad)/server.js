const express = require("express");
const bodyParser = require("body-parser");
const db = require("./db");

const app = express();

app.use(bodyParser.json());
app.use(express.static("public"));

app.post("/pay", (req, res) => {
    const { userId, merchantId, amount } = req.body;

    db.beginTransaction(err => {
        if (err) return res.status(500).send(err);

        // Deduct from user
        db.query(
            "UPDATE users SET balance = balance - ? WHERE id = ? AND balance >= ?",
            [amount, userId, amount],
            (err, result) => {
                if (err || result.affectedRows === 0) {
                    return db.rollback(() => {
                        res.send("❌ Transaction Failed (Insufficient Balance)");
                    });
                }

                // Add to merchant
                db.query(
                    "UPDATE merchants SET balance = balance + ? WHERE id = ?",
                    [amount, merchantId],
                    (err) => {
                        if (err) {
                            return db.rollback(() => {
                                res.send("❌ Transaction Failed");
                            });
                        }

                        // SUCCESS → COMMIT
                        db.commit(err => {
                            if (err) {
                                return db.rollback(() => {
                                    res.send("❌ Commit Failed");
                                });
                            }
                            res.send("✅ Payment Successful");
                        });
                    }
                );
            }
        );
    });
});

app.listen(3000, () => {
    console.log("Server running at http://localhost:3000");
});

