function makePayment() {
    const userId = document.getElementById("userId").value;
    const merchantId = document.getElementById("merchantId").value;
    const amount = document.getElementById("amount").value;

    fetch("/pay", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({ userId, merchantId, amount })
    })
    .then(res => res.text())
    .then(data => {
        document.getElementById("result").innerText = data;
    })
    .catch(err => console.log(err));
}

